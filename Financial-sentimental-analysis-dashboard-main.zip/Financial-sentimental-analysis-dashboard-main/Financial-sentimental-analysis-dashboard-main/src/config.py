import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Centralized configuration for the financial sentiment analysis system"""
    
    # Paths
    BASE_DIR = Path(__file__).parent.parent
    DATA_DIR = BASE_DIR / "data"
    RAW_DATA_DIR = DATA_DIR / "raw"
    PROCESSED_DATA_DIR = DATA_DIR / "processed"
    TRAINING_DATA_DIR = DATA_DIR / "training"
    MODEL_DIR = BASE_DIR / "models"
    SAVED_MODEL_DIR = MODEL_DIR / "saved"
    LOG_DIR = BASE_DIR / "logs"
    
    # API Keys (Optional - system works without them)
    STOCKTWITS_TOKEN = os.getenv("STOCKTWITS_TOKEN", "")
    REDDIT_CLIENT_ID = os.getenv("REDDIT_CLIENT_ID", "")
    REDDIT_CLIENT_SECRET = os.getenv("REDDIT_CLIENT_SECRET", "")
    REDDIT_USER_AGENT = os.getenv("REDDIT_USER_AGENT", "SentimentBot/1.0")
    
    # Financial Instruments to Track
    INSTRUMENTS = {
        "Bitcoin": ["BTC", "BTC-USD", "BITCOIN"],
        "EURUSD": ["EUR", "EURUSD", "EURO"],
        "NASDAQ": ["NASDAQ", "NDX", "QQQ"],
        "Stocks": ["AAPL", "TSLA", "GOOGL", "MSFT", "NVDA"]
    }
    
    # Model Configuration
    MODEL_TYPE = "custom_finbert"  # Options: 'custom_finbert', 'sklearn', 'lstm'
    PRETRAINED_MODEL = "yiyanghkust/finbert-tone"
    MAX_LENGTH = 128
    BATCH_SIZE = 16
    LEARNING_RATE = 2e-5
    EPOCHS = 3
    
    # Data Collection
    COLLECT_LIMIT = 100  # Number of posts per source
    REFRESH_INTERVAL = 300  # seconds
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    @classmethod
    def setup(cls):
        """Create necessary directories"""
        for directory in [cls.RAW_DATA_DIR, cls.PROCESSED_DATA_DIR, 
                         cls.TRAINING_DATA_DIR, cls.SAVED_MODEL_DIR, cls.LOG_DIR]:
            directory.mkdir(parents=True, exist_ok=True)

Config.setup()