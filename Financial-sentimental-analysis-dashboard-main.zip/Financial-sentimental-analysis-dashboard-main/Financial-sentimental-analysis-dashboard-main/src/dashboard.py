import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
import logging
from pathlib import Path

from src.config import Config
from src.data_collector import MultiSourceCollector
from src.text_preprocessor import FinancialTextPreprocessor
from src.sentiment_model import CustomSentimentModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page config
st.set_page_config(
    page_title="AI Financial Sentiment Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        padding: 1rem 0;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .positive { color: #00C853; font-weight: bold; }
    .negative { color: #D50000; font-weight: bold; }
    .neutral { color: #FFD600; font-weight: bold; }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def load_model():
    """Load the trained sentiment model"""
    model_path = Config.SAVED_MODEL_DIR / "custom_sentiment_model"
    
    if model_path.exists():
        logger.info("Loading custom trained model...")
        model = CustomSentimentModel()
        model.load_model(str(model_path))
        return model
    else:
        logger.info("Loading pre-trained model...")
        return CustomSentimentModel()

@st.cache_data(ttl=300)
def load_data(instruments, limit):
    """Collect and analyze data"""
    # Collect data
    collector = MultiSourceCollector()
    df = collector.collect_all(instruments, limit)
    
    if df.empty:
        return df
    
    # Preprocess
    preprocessor = FinancialTextPreprocessor()
    df['cleaned_text'] = preprocessor.preprocess_batch(df['text'].tolist())
    
    # Analyze sentiment
    model = load_model()
    predictions = model.predict_batch(df['cleaned_text'].tolist())
    
    # Add results to dataframe
    df['sentiment'] = [p['label'] for p in predictions]
    df['confidence'] = [p['confidence'] for p in predictions]
    df['prob_positive'] = [p['probabilities']['positive'] for p in predictions]
    df['prob_negative'] = [p['probabilities']['negative'] for p in predictions]
    df['prob_neutral'] = [p['probabilities']['neutral'] for p in predictions]
    
    # Calculate sentiment score (-1 to +1)
    df['sentiment_score'] = df['prob_positive'] - df['prob_negative']
    
    return df

def main():
    # Header
    st.markdown('<h1 class="main-header">🤖 AI-Powered Financial Sentiment Dashboard</h1>', 
                unsafe_allow_html=True)
    st.markdown("**Real-time sentiment analysis using custom fine-tuned FinBERT model**")
    st.markdown("---")
    
    # Sidebar
    # Sidebar
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # Instrument selection
        st.subheader("Select Financial Instruments")
        instruments = st.multiselect(
            "Choose instruments to analyze:",
            options=["BTC-USD", "AAPL", "TSLA", "GOOGL", "MSFT", "NVDA", "AMZN", 
                    "EURUSD=X", "^IXIC"],
            default=["BTC-USD", "AAPL", "TSLA"]
        )
        
        # Data collection limit
        limit = st.slider("Data collection limit", 50, 200, 100)
        
        # Refresh button
        if st.button("🔄 Refresh Data", type="primary"):
            st.cache_data.clear()
            st.rerun()
        
        st.markdown("---")
        
        # Model info
        st.markdown("### 🧠 AI Model")
        model_path = Config.SAVED_MODEL_DIR / "custom_sentiment_model"
        if model_path.exists():
            st.success("✅ Custom FinBERT")
        else:
            st.info("📦 Pre-trained FinBERT")
        
        st.markdown("---")
        
        # Data sources with dynamic status
        st.markdown("### 📚 Data Sources")
        
        import os
        from dotenv import load_dotenv
        load_dotenv()
        
        # API-based sources (check availability)
        st.markdown("**Premium Sources:**")
        
        if os.getenv('ALPHA_VANTAGE_KEY'):
            st.markdown("- ✅ **Alpha Vantage** (25/day)")
        else:
            st.markdown("- ⚪ Alpha Vantage (*add key*)")
        
        if os.getenv('FINNHUB_KEY'):
            st.markdown("- ✅ **Finnhub** (60/min)")
        else:
            st.markdown("- ⚪ Finnhub (*add key*)")
        
        if os.getenv('NEWSAPI_KEY'):
            st.markdown("- ✅ **NewsAPI** (100/day)")
        else:
            st.markdown("- ⚪ NewsAPI (*add key*)")
        
        if os.getenv('MARKETAUX_KEY'):
            st.markdown("- ✅ **Marketaux** (100/day)")
        else:
            st.markdown("- ⚪ Marketaux (*add key*)")
        
        # Always available sources
        st.markdown("**Free Sources:**")
        st.markdown("""
        - 📡 RSS News Feeds
        - ₿ CryptoCompare
        - 📊 Fear & Greed Index
        - 💬 Community Discussions
        """)
        
        # Show total active sources
        active_count = sum([
            bool(os.getenv('ALPHA_VANTAGE_KEY')),
            bool(os.getenv('FINNHUB_KEY')),
            bool(os.getenv('NEWSAPI_KEY')),
            bool(os.getenv('MARKETAUX_KEY'))
        ]) + 4  # 4 free sources always active
        
        st.success(f"**{active_count} sources active**")
        
        # Setup hint
        if active_count == 4:
            st.info("💡 **Tip:** Add API keys to .env for 100+ more articles!")
            with st.expander("🔑 How to add API keys"):
                st.markdown("""
                **Quick Setup (2 mins each):**
                
                1. **Alpha Vantage** (BEST)
                   - Get key: [alphavantage.co](https://www.alphavantage.co/support/#api-key)
                   - Free: 25 requests/day
                
                2. **Finnhub**
                   - Get key: [finnhub.io](https://finnhub.io/register)
                   - Free: 60 requests/min
                
                3. **NewsAPI**
                   - Get key: [newsapi.org](https://newsapi.org/register)
                   - Free: 100 requests/day
                
                **Add to .env file:**
```
                ALPHA_VANTAGE_KEY=your_key
                FINNHUB_KEY=your_key
                NEWSAPI_KEY=your_key
```
                Then restart dashboard!
                """)
        
        st.markdown("---")
        
        # Stats
        st.markdown("### 📊 Current Session")
        if 'data_loaded' in st.session_state:
            st.metric("Data Points", st.session_state.get('data_count', 0))
        
        st.markdown("---")
        
        # About
        with st.expander("ℹ️ About"):
            st.markdown("""
            **Financial Sentiment Dashboard**
            
            Analyzes market sentiment using:
            - 🤖 Custom FinBERT AI model
            - 📰 Real-time news aggregation
            - 📊 Advanced NLP processing
            - 📈 Interactive visualizations
            
            Built with Python, PyTorch, Streamlit
            """)
    
    # Load data
    if not instruments:
        st.warning("⚠️ Please select at least one financial instrument")
        return
    
    with st.spinner("🔄 Collecting and analyzing data..."):
        df = load_data(tuple(instruments), limit)
    
    if df.empty:
        st.error("❌ No data collected. Please check your internet connection.")
        return
    
    # Filter by instrument
    instrument_filter = st.selectbox(
        "Filter by instrument:",
        options=["All"] + list(df['instrument'].unique())
    )
    
    if instrument_filter != "All":
        df_filtered = df[df['instrument'] == instrument_filter]
    else:
        df_filtered = df
    
    # KPI Metrics
    st.subheader("📊 Key Performance Indicators")
    
    # Save data count for sidebar
    st.session_state['data_loaded'] = True
    st.session_state['data_count'] = len(df_filtered)
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric("Total Mentions", f"{len(df_filtered):,}")
    
    with col2:
        positive_pct = (df_filtered['sentiment'] == 'positive').sum() / len(df_filtered) * 100
        st.metric("Positive", f"{positive_pct:.1f}%", 
                    delta=f"+{positive_pct-33:.1f}%" if positive_pct > 33 else f"{positive_pct-33:.1f}%")
    
    with col3:
        negative_pct = (df_filtered['sentiment'] == 'negative').sum() / len(df_filtered) * 100
        st.metric("Negative", f"{negative_pct:.1f}%",
                    delta=f"{negative_pct-33:.1f}%" if negative_pct > 33 else f"{negative_pct-33:.1f}%",
                    delta_color="inverse")
    
    with col4:
        neutral_pct = (df_filtered['sentiment'] == 'neutral').sum() / len(df_filtered) * 100
        st.metric("Neutral", f"{neutral_pct:.1f}%")
    
    with col5:
        avg_confidence = df_filtered['confidence'].mean()
        st.metric("Avg Confidence", f"{avg_confidence:.1%}")
    
    # Show data sources count
    num_sources = len(df['source'].unique())
    st.info(f"📊 Data collected from **{num_sources} sources** | Last updated: {datetime.now().strftime('%H:%M:%S')}")
    
    st.markdown("---")
    
    # Main tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "📈 Sentiment Overview", 
        "⏱️ Time Series Analysis",
        "🎯 Instrument Breakdown",
        "📝 Raw Data"
    ])
    
    with tab1:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Sentiment Distribution")
            
            sentiment_counts = df_filtered['sentiment'].value_counts()
            
            fig = px.pie(
                values=sentiment_counts.values,
                names=sentiment_counts.index,
                color=sentiment_counts.index,
                color_discrete_map={
                    'positive': '#00C853',
                    'neutral': '#FFD600',
                    'negative': '#D50000'
                },
                hole=0.4,
                title="Overall Sentiment Distribution"
            )
            
            fig.update_traces(textposition='inside', textinfo='percent+label',
                            textfont_size=14)
            fig.update_layout(height=400)
            
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.subheader("Sentiment Score Distribution")
            
            fig = px.histogram(
                df_filtered,
                x='sentiment_score',
                nbins=30,
                color='sentiment',
                color_discrete_map={
                    'positive': '#00C853',
                    'neutral': '#FFD600',
                    'negative': '#D50000'
                },
                title="Sentiment Score Range"
            )
            
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        # Source breakdown
        st.subheader("Sentiment by Data Source")
        
        source_sentiment = df_filtered.groupby(['source', 'sentiment']).size().reset_index(name='count')
        
        fig = px.bar(
            source_sentiment,
            x='source',
            y='count',
            color='sentiment',
            color_discrete_map={
                'positive': '#00C853',
                'neutral': '#FFD600',
                'negative': '#D50000'
            },
            barmode='group',
            title="Data Source Analysis"
        )
        
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("⏱️ Sentiment Over Time")
        
        # Aggregate by hour
        df_filtered['hour'] = pd.to_datetime(df_filtered['timestamp']).dt.floor('H')
        
        hourly_sentiment = df_filtered.groupby(['hour', 'sentiment']).size().reset_index(name='count')
        
        fig = px.line(
            hourly_sentiment,
            x='hour',
            y='count',
            color='sentiment',
            color_discrete_map={
                'positive': '#00C853',
                'neutral': '#FFD600',
                'negative': '#D50000'
            },
            markers=True,
            title="Sentiment Trends Over Time"
        )
        
        fig.update_layout(height=400, hovermode='x unified')
        st.plotly_chart(fig, use_container_width=True)
        
        # Sentiment score over time
        hourly_score = df_filtered.groupby('hour')['sentiment_score'].mean().reset_index()
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=hourly_score['hour'],
            y=hourly_score['sentiment_score'],
            mode='lines+markers',
            name='Sentiment Score',
            line=dict(color='#667eea', width=3),
            marker=dict(size=8),
            fill='tozeroy'
        ))
        
        fig.add_hline(y=0, line_dash="dash", line_color="gray",
                     annotation_text="Neutral Line")
        
        fig.update_layout(
            title="Average Sentiment Score Over Time",
            xaxis_title="Time",
            yaxis_title="Sentiment Score (-1 to +1)",
            height=400,
            hovermode='x unified'
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.subheader("🎯 Instrument-Specific Analysis")
        
        # Sentiment by instrument
        instrument_sentiment = df.groupby(['instrument', 'sentiment']).size().reset_index(name='count')
        
        fig = px.bar(
            instrument_sentiment,
            x='instrument',
            y='count',
            color='sentiment',
            color_discrete_map={
                'positive': '#00C853',
                'neutral': '#FFD600',
                'negative': '#D50000'
            },
            barmode='stack',
            title="Sentiment Distribution by Instrument"
        )
        
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
        
        # Average sentiment score by instrument
        instrument_score = df.groupby('instrument').agg({
            'sentiment_score': 'mean',
            'confidence': 'mean',
            'text': 'count'
        }).reset_index()
        instrument_score.columns = ['Instrument', 'Avg Sentiment Score', 'Avg Confidence', 'Mentions']
        instrument_score = instrument_score.sort_values('Avg Sentiment Score', ascending=False)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.bar(
                instrument_score,
                x='Instrument',
                y='Avg Sentiment Score',
                color='Avg Sentiment Score',
                color_continuous_scale=['red', 'yellow', 'green'],
                color_continuous_midpoint=0,
                title="Average Sentiment Score by Instrument"
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.dataframe(
                instrument_score.style.background_gradient(
                    subset=['Avg Sentiment Score'],
                    cmap='RdYlGn',
                    vmin=-1,
                    vmax=1
                ).format({
                    'Avg Sentiment Score': '{:.3f}',
                    'Avg Confidence': '{:.1%}',
                    'Mentions': '{:.0f}'
                }),
                use_container_width=True,
                height=400
            )
    
    with tab4:
        st.subheader("📝 Raw Data View")
        
        # Display columns
        display_df = df_filtered[[
            'timestamp', 'instrument', 'source', 'text', 
            'sentiment', 'confidence', 'sentiment_score'
        ]].copy()
        
        display_df['timestamp'] = pd.to_datetime(display_df['timestamp']).dt.strftime('%Y-%m-%d %H:%M')
        display_df['text'] = display_df['text'].str[:150] + '...'
        display_df = display_df.sort_values('timestamp', ascending=False)
        
        # Apply styling
        def highlight_sentiment(row):
            if row['sentiment'] == 'positive':
                return ['background-color: #E8F5E9'] * len(row)
            elif row['sentiment'] == 'negative':
                return ['background-color: #FFEBEE'] * len(row)
            else:
                return ['background-color: #FFF9C4'] * len(row)
        
        st.dataframe(
            display_df.head(100).style.apply(highlight_sentiment, axis=1).format({
                'confidence': '{:.1%}',
                'sentiment_score': '{:.3f}'
            }),
            use_container_width=True,
            height=600
        )
        
        # Download button
        csv = display_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Data as CSV",
            data=csv,
            file_name=f"sentiment_data_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv"
        )
    
    # Footer
    st.markdown("---")
    
    # Dynamic data sources in footer
    import os
    active_sources = []
    
    if os.getenv('ALPHA_VANTAGE_KEY'):
        active_sources.append("Alpha Vantage")
    if os.getenv('FINNHUB_KEY'):
        active_sources.append("Finnhub")
    if os.getenv('NEWSAPI_KEY'):
        active_sources.append("NewsAPI")
    if os.getenv('MARKETAUX_KEY'):
        active_sources.append("Marketaux")
    
    active_sources.extend(["RSS Feeds", "CryptoCompare", "Fear & Greed Index"])
    
    sources_text = ", ".join(active_sources)
    
    st.markdown(f"""
    <div style='text-align: center; color: gray;'>
        <p>🤖 Powered by Custom Fine-Tuned FinBERT | Built with Streamlit & PyTorch</p>
        <p>📊 Data Sources: {sources_text}</p>
        <p style='font-size: 0.8em;'>Real-time sentiment analysis using advanced NLP and multiple news APIs</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()