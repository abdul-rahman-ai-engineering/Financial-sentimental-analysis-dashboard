import torch
from transformers import (
    BertTokenizer, 
    BertForSequenceClassification,
    AdamW,
    get_linear_schedule_with_warmup
)
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import logging
from typing import List, Dict, Tuple
from src.config import Config

logger = logging.getLogger(__name__)

class SentimentDataset(Dataset):
    """Custom dataset for sentiment analysis"""
    
    def __init__(self, texts, labels, tokenizer, max_length=128):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }

class CustomSentimentModel:
    """Custom fine-tuned FinBERT sentiment classifier"""
    
    def __init__(self, model_name: str = None, num_labels: int = 3):
        self.model_name = model_name or Config.PRETRAINED_MODEL
        self.num_labels = num_labels
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        logger.info(f"Initializing model: {self.model_name}")
        logger.info(f"Device: {self.device}")
        
        # Load tokenizer
        self.tokenizer = BertTokenizer.from_pretrained(self.model_name)
        
        # Load model
        self.model = BertForSequenceClassification.from_pretrained(
            self.model_name,
            num_labels=self.num_labels
        ).to(self.device)
        
        # Label mapping
        self.label_map = {0: 'negative', 1: 'neutral', 2: 'positive'}
        self.reverse_label_map = {'negative': 0, 'neutral': 1, 'positive': 2}
        
        logger.info("Model initialized successfully")
    
    def train(self, train_texts: List[str], train_labels: List[int], 
              val_texts: List[str] = None, val_labels: List[int] = None,
              epochs: int = 3, batch_size: int = 16, learning_rate: float = 2e-5):
        """Fine-tune the model on custom data"""
        
        logger.info(f"Starting training: {len(train_texts)} samples")
        
        # Create datasets
        train_dataset = SentimentDataset(
            train_texts, train_labels, self.tokenizer, Config.MAX_LENGTH
        )
        
        train_loader = DataLoader(
            train_dataset, 
            batch_size=batch_size, 
            shuffle=True
        )
        
        # Optimizer and scheduler
        optimizer = AdamW(self.model.parameters(), lr=learning_rate)
        total_steps = len(train_loader) * epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=0,
            num_training_steps=total_steps
        )
        
        # Training loop
        self.model.train()
        
        for epoch in range(epochs):
            total_loss = 0
            
            for batch in train_loader:
                # Move batch to device
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                # Forward pass
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss
                total_loss += loss.item()
                
                # Backward pass
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                scheduler.step()
            
            avg_loss = total_loss / len(train_loader)
            logger.info(f"Epoch {epoch + 1}/{epochs} - Loss: {avg_loss:.4f}")
            
            # Validation
            if val_texts is not None:
                val_accuracy = self.evaluate(val_texts, val_labels)
                logger.info(f"Validation Accuracy: {val_accuracy:.4f}")
        
        logger.info("Training completed!")
    
    def evaluate(self, texts: List[str], labels: List[int]) -> float:
        """Evaluate model performance"""
        predictions = self.predict_batch(texts)
        pred_labels = [self.reverse_label_map[p['label']] for p in predictions]
        accuracy = accuracy_score(labels, pred_labels)
        return accuracy
    
    def predict_single(self, text: str) -> Dict:
        """Predict sentiment for a single text"""
        if not text or len(text.strip()) < 3:
            return {
                'label': 'neutral',
                'confidence': 0.0,
                'probabilities': {'negative': 0.33, 'neutral': 0.34, 'positive': 0.33}
            }
        
        self.model.eval()
        
        # Tokenize
        encoding = self.tokenizer(
            text,
            add_special_tokens=True,
            max_length=Config.MAX_LENGTH,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        input_ids = encoding['input_ids'].to(self.device)
        attention_mask = encoding['attention_mask'].to(self.device)
        
        # Predict
        with torch.no_grad():
            outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
            probs = torch.nn.functional.softmax(outputs.logits, dim=1)[0]
        
        # Get results
        predicted_class = probs.argmax().item()
        confidence = probs.max().item()
        
        return {
            'label': self.label_map[predicted_class],
            'confidence': float(confidence),
            'probabilities': {
                'negative': float(probs[0]),
                'neutral': float(probs[1]),
                'positive': float(probs[2])
            }
        }
    
    def predict_batch(self, texts: List[str]) -> List[Dict]:
        """Predict sentiment for multiple texts"""
        results = []
        
        # Process in batches
        batch_size = 32
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i+batch_size]
            
            for text in batch_texts:
                result = self.predict_single(text)
                results.append(result)
        
        logger.info(f"Predicted sentiment for {len(texts)} texts")
        return results
    
    def save_model(self, path: str):
        """Save fine-tuned model"""
        self.model.save_pretrained(path)
        self.tokenizer.save_pretrained(path)
        logger.info(f"Model saved to {path}")
    
    def load_model(self, path: str):
        """Load fine-tuned model"""
        self.model = BertForSequenceClassification.from_pretrained(path).to(self.device)
        self.tokenizer = BertTokenizer.from_pretrained(path)
        logger.info(f"Model loaded from {path}")