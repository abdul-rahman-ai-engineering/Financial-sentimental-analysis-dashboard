import re
import nltk
from typing import List
import logging

logger = logging.getLogger(__name__)

# Download NLTK data at module level (before class definition)
try:
    # Force download to ensure data is available
    nltk.download('stopwords', quiet=True)
    nltk.download('punkt', quiet=True)
except:
    pass

# Import stopwords after download
try:
    from nltk.corpus import stopwords
    STOPWORDS = set(stopwords.words('english'))
except Exception as e:
    logger.warning(f"Could not load NLTK stopwords: {e}. Using minimal set.")
    # Fallback stopwords if NLTK fails
    STOPWORDS = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 
                 'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
                 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
                 'should', 'could', 'may', 'might', 'must', 'can', 'this', 'that',
                 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they'}

class FinancialTextPreprocessor:
    """Advanced text preprocessing for financial sentiment analysis"""
    
    def __init__(self):
        # Use global stopwords set
        self.stopwords = STOPWORDS.copy()
        
        # Keep sentiment-important words
        self.keep_words = {'not', 'no', 'nor', 'never', 'up', 'down', 'high', 'low', 
                          'more', 'less', 'bull', 'bear', 'buy', 'sell', 'rise', 'fall'}
        self.stopwords -= self.keep_words
        
        # Financial domain keywords
        self.financial_terms = {
            'positive': ['bull', 'bullish', 'moon', 'gain', 'profit', 'surge', 'rally', 
                        'breakout', 'momentum', 'strong', 'beat', 'exceeded'],
            'negative': ['bear', 'bearish', 'crash', 'loss', 'dump', 'decline', 'drop',
                        'resistance', 'weak', 'missed', 'below', 'concern']
        }
        
        logger.info("Text preprocessor initialized")
    
    def preprocess(self, text: str, for_model: str = 'bert') -> str:
        """
        Clean and preprocess text
        
        Args:
            text: Input text
            for_model: 'bert' (minimal preprocessing) or 'sklearn' (full preprocessing)
        """
        if not text or not isinstance(text, str):
            return ""
        
        # Basic cleaning
        text = self._clean_text(text)
        
        if for_model == 'sklearn':
            # More aggressive preprocessing for traditional ML
            text = self._advanced_clean(text)
        
        return text.strip()
    
    def _clean_text(self, text: str) -> str:
        """Basic text cleaning"""
        # Remove URLs
        text = re.sub(r'https?://\S+|www\.\S+', '', text)
        
        # Remove mentions and hashtags but keep the text
        text = re.sub(r'@\w+', '', text)
        text = re.sub(r'#(\w+)', r'\1', text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        # Remove special characters but keep important punctuation
        text = re.sub(r'[^a-zA-Z0-9\s\.\!\?]', '', text)
        
        return text
    
    def _advanced_clean(self, text: str) -> str:
        """Advanced cleaning for traditional ML models"""
        # Lowercase
        text = text.lower()
        
        # Simple tokenization (split on whitespace)
        tokens = text.split()
        
        # Remove stopwords
        tokens = [t for t in tokens if t not in self.stopwords]
        
        # Join back
        return ' '.join(tokens)
    
    def preprocess_batch(self, texts: List[str], for_model: str = 'bert') -> List[str]:
        """Preprocess multiple texts"""
        cleaned = [self.preprocess(text, for_model) for text in texts]
        
        # Filter out too-short texts
        cleaned = [t if len(t.split()) >= 3 else "" for t in cleaned]
        
        logger.info(f"Preprocessed {len(texts)} texts, {sum(1 for t in cleaned if t)} valid")
        return cleaned
    
    def extract_features(self, text: str) -> dict:
        """Extract additional features for analysis"""
        text_lower = text.lower()
        
        return {
            'length': len(text.split()),
            'has_positive_words': sum(1 for word in self.financial_terms['positive'] 
                                     if word in text_lower),
            'has_negative_words': sum(1 for word in self.financial_terms['negative'] 
                                     if word in text_lower),
            'has_numbers': bool(re.search(r'\d', text)),
            'has_exclamation': '!' in text
        }