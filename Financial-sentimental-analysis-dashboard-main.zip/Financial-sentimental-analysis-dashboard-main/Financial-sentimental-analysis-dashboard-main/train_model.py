import pandas as pd
import logging
from pathlib import Path
from src.config import Config
from src.data_collector import MultiSourceCollector
from src.text_preprocessor import FinancialTextPreprocessor
from src.sentiment_model import CustomSentimentModel

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_training_data():
    """Create labeled training dataset"""
    
    # Sample labeled data for financial sentiment
    training_data = {
        'text': [
            # Positive examples
            "Bitcoin price surges to new all-time high! Bull market confirmed!",
            "Company beats earnings expectations, stock soars 15%",
            "Strong buying momentum, technical indicators look bullish",
            "Breaking: Major partnership announcement sends crypto prices higher",
            "Nasdaq rallies on positive economic data",
            "Investors confident as market reaches new highs",
            "Revenue growth exceeds analyst predictions",
            "Strong fundamentals support continued upward trend",
            "Market sentiment extremely positive today",
            "Bulls in full control, resistance levels broken",
            
            # Negative examples
            "Market crash imminent, investors panic selling",
            "Bitcoin plunges 20% amid regulatory concerns",
            "Company misses earnings, stock drops sharply",
            "Technical indicators showing bearish divergence",
            "Sell-off continues as fears mount",
            "Nasdaq tumbles on recession worries",
            "Weak earnings report disappoints investors",
            "Major resistance at current levels, expect pullback",
            "Market sentiment turning bearish",
            "Bears take control, support levels broken",
            
            # Neutral examples
            "Market consolidating in tight range",
            "Trading volume remains average",
            "Price action indecisive, waiting for catalyst",
            "Mixed signals from technical indicators",
            "Sideways movement expected to continue",
            "No clear direction in today's trading",
            "Market awaiting economic data release",
            "Balanced buying and selling pressure",
            "Range-bound trading likely continues",
            "Neutral sentiment prevails in current session"
        ],
        'label': [
            'positive', 'positive', 'positive', 'positive', 'positive',
            'positive', 'positive', 'positive', 'positive', 'positive',
            'negative', 'negative', 'negative', 'negative', 'negative',
            'negative', 'negative', 'negative', 'negative', 'negative',
            'neutral', 'neutral', 'neutral', 'neutral', 'neutral',
            'neutral', 'neutral', 'neutral', 'neutral', 'neutral'
        ]
    }
    
    df = pd.DataFrame(training_data)
    return df

def train_custom_model():
    """Train custom sentiment model"""
    
    logger.info("=" * 60)
    logger.info("TRAINING CUSTOM SENTIMENT MODEL")
    logger.info("=" * 60)
    
    # Step 1: Create/load training data
    logger.info("\n📚 Step 1: Preparing training data...")
    train_df = create_training_data()
    logger.info(f"Training samples: {len(train_df)}")
    logger.info(f"Label distribution:\n{train_df['label'].value_counts()}")
    
    # Step 2: Preprocess texts
    logger.info("\n🧹 Step 2: Preprocessing texts...")
    preprocessor = FinancialTextPreprocessor()
    train_df['cleaned_text'] = preprocessor.preprocess_batch(
        train_df['text'].tolist(), 
        for_model='bert'
    )
    
    # Step 3: Convert labels to integers
    label_map = {'negative': 0, 'neutral': 1, 'positive': 2}
    train_df['label_id'] = train_df['label'].map(label_map)
    
    # Step 4: Split data
    from sklearn.model_selection import train_test_split
    train_texts, val_texts, train_labels, val_labels = train_test_split(
        train_df['cleaned_text'].tolist(),
        train_df['label_id'].tolist(),
        test_size=0.2,
        random_state=42,
        stratify=train_df['label_id']
    )
    
    logger.info(f"Train samples: {len(train_texts)}")
    logger.info(f"Validation samples: {len(val_texts)}")
    
    # Step 5: Initialize and train model
    logger.info("\n🤖 Step 3: Training model...")
    model = CustomSentimentModel()
    
    model.train(
        train_texts=train_texts,
        train_labels=train_labels,
        val_texts=val_texts,
        val_labels=val_labels,
        epochs=Config.EPOCHS,
        batch_size=Config.BATCH_SIZE,
        learning_rate=Config.LEARNING_RATE
    )
    
    # Step 6: Save model
    logger.info("\n💾 Step 4: Saving model...")
    model_path = Config.SAVED_MODEL_DIR / "custom_sentiment_model"
    model.save_model(str(model_path))
    
    # Step 7: Test predictions
    logger.info("\n🧪 Step 5: Testing predictions...")
    test_texts = [
        "Bitcoin to the moon! 🚀",
        "Market crash coming soon",
        "Sideways movement today"
    ]
    
    for text in test_texts:
        result = model.predict_single(text)
        logger.info(f"Text: '{text}'")
        logger.info(f"Prediction: {result['label']} (confidence: {result['confidence']:.2%})")
        logger.info("-" * 40)
    
    logger.info("\n✅ TRAINING COMPLETED SUCCESSFULLY!")
    logger.info(f"Model saved to: {model_path}")
    
    return model

if __name__ == "__main__":
    train_custom_model()